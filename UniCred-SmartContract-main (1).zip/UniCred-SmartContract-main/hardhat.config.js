require('dotenv').config();
require("@nomiclabs/hardhat-waffle");
require('@openzeppelin/hardhat-upgrades')

const api_key = process.env.ALCHEMY_GOERLI_API_KEY;

/**
 * @type import('hardhat/config').HardhatUserConfig
 */
module.exports = {
  networks: {
    hardhat: {
      chainId: 1337,
    },
    goerli: {
      url: `https://eth-goerli.g.alchemy.com/v2/${api_key}`, 
      accounts: [process.env.PRIVATE_KEY],
    },
  },
  solidity: {

    compilers: [
      {
          version: "0.6.12",
          settings: {
              optimizer: {
                  enabled: true,
                  runs: 200,
              },
          },
      },
      {
        version: '0.8.4',
        settings: {
          optimizer: {
            enabled: true,
            runs: 200,
          },
        },
      },
      {
          version: "0.8.7",
          settings: {
              optimizer: {
                  enabled: false,
                  runs: 200,
              },
          },
      },
    ],   
  },
};
