const { expect } = require("chai");
const { ethers, waffle } = require("hardhat");

const { fromBigNum, toBigNum } = require("./utils/common");

const provider = waffle.provider;
let tokenOwner, uniCredToken;

describe("UniCred", function () {
    it("Should create and execute UniCred", async function () {
        [tokenOwner, userWallet1, userWallet2] = await ethers.getSigners();

        console.log("Owner Address : ", tokenOwner.address);       
   
        // UniCred token deploy...

        const UniCredToken = await ethers.getContractFactory('UniCredToken');
        uniCredToken = await UniCredToken.deploy('UniCredToken', "UCT", toBigNum("1000000000"));
        await uniCredToken.deployed();

        console.log("Totalsupply :", fromBigNum(await uniCredToken.totalSupply()));
        console.log("Balance of Owner : ", fromBigNum(await uniCredToken.balanceOf(tokenOwner.address)));
    });
    
    it("Should transfer with correct fees", async function() {
        await uniCredToken.setPrice(toBigNum("1.25"));
        console.log("Token Price : ", fromBigNum(await uniCredToken.getPrice()));

        console.log("Blance of userWallet1 before sending : ", fromBigNum(await uniCredToken.balanceOf(userWallet1.address)));
        await uniCredToken.transfer(userWallet1.address, toBigNum("100"));
        console.log("Blance of userWallet1 after sending : ", fromBigNum(await uniCredToken.balanceOf(userWallet1.address)));


        console.log("Blance of userWallet2 before sending : ", fromBigNum(await uniCredToken.balanceOf(userWallet2.address)));
        await uniCredToken.transfer(userWallet2.address, toBigNum("20000"));
        console.log("Blance of userWallet2 after sending : ", fromBigNum(await uniCredToken.balanceOf(userWallet2.address)));
    });

});